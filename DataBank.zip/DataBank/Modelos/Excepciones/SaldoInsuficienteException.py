class SaldoInsuficienteException(Exception):
    pass