from datetime import datetime
from Modelos.Roles.Empleado import Empleado
from Modelos.AutenticableHelper.AutenticableHelper import AutenticableHelper

class EmpleadoAutenticable(Empleado):
    def __init__(self, name: str, dni: int, position: str, salary: float, experience: int, password: str):
        super().__init__(name, dni, position, salary, experience)
        self._helper = AutenticableHelper()
        self.__password = password
        self.locked_until = None

    def get_password(self):
        return self.__password
    
    def authenticate_user(self, new_password: str):
        return self._helper.comparate_passwords(self.get_password(), new_password)

    def obtain_bonus(self) -> float:
        return 0
    
    def is_blocked(self):
        if self.locked_until is not None and datetime.now() >= self.locked_until:
            self.locked_until = None
            return False
        return self.locked_until is not None
    
    def to_dict(self):
        data = super().to_dict()
        data["password"] = self.get_password()
        return data