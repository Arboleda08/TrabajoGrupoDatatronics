import uuid
from Modelos.Roles.Empleado import Empleado
from datetime import datetime

class Log:
    def __init__(self, employee: Empleado, action: str, status: bool, details: str = ""):
        self.id = uuid.uuid4().hex[:8]
        self.date = datetime.now()
        self.employee = employee
        self.action = action
        self.status = status 
        self.details = details

    def to_dict(self):
        return {
            "id": self.id,
            "date": self.date.isoformat(),
            "employee_dni": self.employee.get_dni(),
            "action": self.action,
            "status": self.status,
            "details": self.details
        }