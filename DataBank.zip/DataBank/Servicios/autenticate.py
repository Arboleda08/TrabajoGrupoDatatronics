from Servicios.Banco import Banco
from Modelos.Roles.EmpleadoAutenticable import EmpleadoAutenticable
from Modelos.Roles.Empleado import Empleado

class AutenticateObjects:
    def __init__(self, bank: "Banco"):
        self.bank = bank
    
    def autenticate_user(self, employee: "EmpleadoAutenticable", password: str):
        if employee.authenticate_user(password):
            return True

        self.verify_failed_attempt(employee)
        return False
    
    def verify_failed_attempt(self, employee: "Empleado"):
        employee.failed_attempts +=1

        if employee.failed_attempts >= 3:
            self.block_employee(employee)

    def block_employee(self, employee: "Empleado"):
        employee.is_blocked= True


    def unblock_employee(self, employee: "Empleado"):
        employee.is_blocked = False
        employee.failed_attempts = 0

        def suspicious_login_detection(self):
          if self.employee_login_history() > 3:
              return True
          elif self.password_attempts() > 3:
              return True
          elif self.unusual_location_login():
              return True
          elif self.password_change_history() > 3:
              return True
          elif self.password != self.password:
              return True