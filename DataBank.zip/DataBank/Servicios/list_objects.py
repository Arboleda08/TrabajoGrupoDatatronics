from Modelos.Cuentas.Cliente import Cliente
from Modelos.Roles.Empleado import Empleado
from Servicios.Banco import Banco

class ListObjects:
    def __init__(self, bank: "Banco"):
        self.bank = bank

    def list_client(self, employee: "Empleado"):
        self.bank.validate_permission(employee, "Ver_informacion")

        return self.bank.clients
    
    def list_accounts(self, employee: "Empleado"):
        self.bank.validate_permission(employee, "Ver_informacion")

        return self.bank.accounts

    def list_accounts_by_client(self, client: "Cliente"):
        accounts = []

        for account in self.bank.accounts:
            if account.client == client:
                accounts.append(account)

        return accounts

    def list_accounts_by_bank(self, new_bank_number: int):
        accounts = []

        for account in self.bank.accounts:
            if account.bank_number == new_bank_number:
                accounts.append(account)

        return accounts

    def list_employees(self, employee: "Empleado"):
        self.bank.validate_permission(employee, "Ver_informacion")

        return self.bank.employees
    
    def list_active_credits(self):
          active_credits = []
          for client in self.bank.clients:
              for credit in client.credits:
                  if credit.status == "Aprobado":
                      active_credits.append(credit)
          return active_credits
    
    def list_cards(self):
        cards = []
        for account in self.bank.accounts:
            for card in account.cards:
                cards.append(card)
        return cards
    
    def list_cards_by_client(self, client: "Cliente"):
        cards = []
        for account in self.bank.accounts:
            if account.client == client:
                for card in account.cards:
                    cards.append(card)
        return cards
        
    
    
