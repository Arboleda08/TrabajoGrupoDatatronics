from Servicios.Banco import Banco
from Modelos.Cuentas.Credito import Credito
from Modelos.Cuentas.Cliente import Cliente
from Modelos.Roles.Empleado import Empleado
from Modelos.Excepciones.OperacionImposibleException import OperacionImposibleException

class ManageCredits:
    def __init__(self, bank: "Banco"):
        self.bank = bank

    def request_credit(self, client: Cliente, amount: float, months: int):
        credit = Credito(amount, self.bank.interest_rate, months, client)
        return credit

    def approve_credit(self, employee: "Empleado", client: Cliente, credit: Credito):
        if not employee.can_approve_credit(credit.amount):
            raise OperacionImposibleException("El empleado no tiene permisos para aprobar créditos.")
        
        if credit not in client.credits:
            raise OperacionImposibleException("El crédito no pertenece a este cliente.")
            
        if credit.status != "Pendiente":
            raise OperacionImposibleException("Sólo se pueden aprobar créditos pendientes.")
            
        credit.approved = True
        credit.status = "Aprobado"

        return True
    
    def reject_credit(self, client: "Cliente", credit: "Credito"):
        if credit not in client.credits:
            raise ValueError("El crédito no pertenece a este cliente")
        
        if credit.status != "Pendiente":
            raise OperacionImposibleException("Sólo se pueden rechazar créditos pendientes")
        
        if client.age > 65:
            credit.approved = False
            credit.status = "Rechazado"
            return "El cliente supera la edad máxima, el crédito ha sido rechazado."
        
        active = []
        for cred in client.credits:
            if cred.status == "Aprobado":
                active.append(cred)
                
        if active:
            credit.approved = False
            credit.status = "Rechazado"
            return "El cliente ya tiene un crédito aprobado, no puede solicitar otro."
        
        pending = []
        for cred in client.credits:
            if cred == credit:
                continue

            if cred.remaining_balance > 0 and cred.status != "Rechazado":
                pending.append(cred)

        if pending:
            credit.approved = False
            credit.status = "Rechazado"
            return "El lciente tiene cuotas pendientes. Solicitud de crédito rechazada."
        
        client_accounts = []
        for acc in self.bank.accounts:
            if acc.client == client:
                client_accounts.append(acc)

        found = False
        for acc in client_accounts:
            if acc.get_balance() < 0:
                found = True
                break
        if found:
            credit.approved = False
            credit.status = "Rechazado"
            return "El cliente tiene saldo negativo en alguna cuenta. Crédito denegado."
        
        raise OperacionImposibleException ("No hay motivo para rechazar el crédito")

 
    def calculate_credit_interest(self, credit: "Credito"):
        return credit.amount * credit.interest_rate * (credit.months / 12)

    def pay_credit_installment(self, client: "Cliente", credit: "Credito", amount: float):
        if credit not in client.credits:
            raise ValueError("El crédito no pertenece a este cliente.")
   
        if credit.status != "Aprobado":
            raise OperacionImposibleException("El crédito no está activo.")
   
        if amount <= 0:
            raise ValueError("El monto de la cuota debe ser mayor a 0.")
   
        if amount > credit.remaining_balance:
            amount = credit.remaining_balance
   
        credit.remaining_balance -= amount
   
        if credit.remaining_balance <= 0:
            credit.remaining_balance = 0
            credit.status = "Pagado"
   
        return credit.remaining_balance
      