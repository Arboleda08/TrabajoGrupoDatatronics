from Servicios.Banco import Banco
from Modelos.Cuentas.CuentaAhorros import CuentaAhorros
from Modelos.Cuentas.CuentaBancaria import CuentaBancaria
from Modelos.Cuentas.CuentaCorriente import CuentaCorriente
from Modelos.Cuentas.CuentaEmpresarial import CuentaEmpresarial
from Modelos.Cuentas.CuentaJuvenil import CuentaJuvenil
from Modelos.Cuentas.Cliente import Cliente
from Modelos.Roles.Empleado import Empleado
from Modelos.Excepciones.OperacionImposibleException import OperacionImposibleException

class ManageAccounts:
    def __init__(self, bank: "Banco"):
        self.bank = bank
    
    def create_account(self, employee: "Empleado", client: "Cliente", account_type: str):
        self.bank.validate_permission(employee, "Crear_cliente")

        account_types = {
            "Ahorros": CuentaAhorros,
            "Corriente": CuentaCorriente,
            "Empresarial": CuentaEmpresarial,
            "Juvenil": CuentaJuvenil
        }

        if account_type not in account_types:
            raise ValueError("Tipo de cuenta inválido")

        account_class = account_types[account_type]

        account = account_class(
            bank_number = self.bank.bank_number,
            client = client
        )

        self.bank.accounts.append(account)

        return account

    def delete_account(self, employee: "Empleado", account: CuentaBancaria):
        self.bank.validate_permission(employee, "Borrar_cuenta")

        if account in self.bank.accounts:
            self.bank.accounts.remove(account)
            return True

        return False
    
    def change_account_status(self, employee: "Empleado", account: CuentaBancaria):
        self.bank.validate_permission(employee, "Borrar_cuenta")

        account.account_active = not account.account_active

        return account.account_active
    
    def close_account(self, employee: "Empleado", account: "CuentaBancaria"):
        self.bank.validate_permission(employee, "Borrar_cuenta")
        if account.get_balance() != 0:
            raise OperacionImposibleException("No se puede cerrar una cuenta con saldo pendiente.")
        account.account_active = False
        self.bank.accounts.remove(account)
        self.bank.register_log("Cierre_de_cuenta", employee, True, "Cierre de cuenta por no uso")
        return True
    
    def apply_monthly_fee(self, employee: "Empleado", account: "CuentaBancaria", fee: float):
        self.bank.validate_permission(employee, "Borrar_cuenta")
        if not account.account_active:
            raise OperacionImposibleException("La cuenta no está activa.")
        if fee <= 0:
            raise ValueError("La comisión debe ser mayor a 0.")
        account.withdraw(fee)
        self.bank.register_log("Cuota de manejo", employee, True, "Cobro de cuota de manejo")
        return account.get_balance()