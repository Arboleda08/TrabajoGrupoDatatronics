import json
from datetime import datetime, timedelta
from Modelos.Cuentas.CuentaBancaria import CuentaBancaria
from Modelos.Cuentas.Cliente import Cliente
from Modelos.Cuentas.Transaction import Transaction
from Modelos.Roles.Empleado import Empleado
from Modelos.Excepciones.OperacionImposibleException import OperacionImposibleException
from Modelos.Log.Log import Log
from Servicios.BonusAdmin import BonusAdmin
from Servicios.analize import Analize
from Servicios.autenticate import AutenticateObjects
from Servicios.list_objects import ListObjects
from Servicios.manage_accounts import ManageAccounts
from Servicios.manage_credits import ManageCredits
from Servicios.manage_employees import ManageEmployees
from Servicios.manage_cards import ManageCards
from Servicios.notificate import Notificate
from Servicios.report import ReportObjects
from Servicios.search import SearchObjects

class Banco:
    def __init__(self, name: str, number: int, clients: list[Cliente], employees: list[Empleado], global_transactions: list[Transaction], logs: list[Log], bonus_admin: BonusAdmin):
        self.name = name
        self.bank_number = number
        self.clients = clients
        self.employees = employees
        self.accounts: list[CuentaBancaria] = []
        self.global_transactions = global_transactions
        self.logs = logs
        self.bonus_admin = bonus_admin
        self.interest_rate = 0.6

        self.analize = Analize(self)
        self.autenticate = AutenticateObjects(self)
        self.list_objects = ListObjects(self)
        self.manage_accounts = ManageAccounts(self)
        self.manage_credits = ManageCredits(self)
        self.manage_employees = ManageEmployees(self)
        self.manage_cards = ManageCards(self)
        self.notificate = Notificate(self)
        self.report = ReportObjects(self)
        self.search = SearchObjects(self)

    def validate_permission(self, employee: "Empleado", action: str):
        permissions = {
            "Crear_empleado": employee.can_create_user(),
            "Eliminar_empleado": employee.can_delete_user(),
            "Ver_informacion": employee.can_see_information(),
            "Ver_reportes": employee.can_see_reports(),
            "Cambiar_rol": employee.can_change_role
        }

        if action not in permissions:
            raise OperacionImposibleException("Operación inválida")
        
        if not permissions[action]:
            raise PermissionError(
                f"{employee.name} no tiene permiso para {action}"
            )
        
        return True

    def create_client(self, employee: "Empleado", client_data):
        self.validate_permission(employee, "Crear_empleado")

        client = Cliente (
            client_data["name"],
            client_data["dni"],
            client_data["age"],
            client_data["profession"]
        )

        self.clients.append(client)
        return client

    def upgrade_client(self, employee: "Empleado", client: "Cliente", account_type: str):
        self.validate_permission(employee, "Crear_empleado")

        return self.manage_accounts.create_account(employee, client, account_type)


    def register_transaction(self, transaction: "Transaction"):
        self.global_transactions.append(transaction)

    def get_account_history(self, account: CuentaBancaria):
        return account.transactions

    def get_client_history(self, client: "Cliente"):
        transactions = []

        for account in self.accounts:
            if account.client == client:
                for transaction in account.transactions:
                    transactions.append(transaction)

        return transactions

    def get_global_transactions(self, employee: "Empleado"):
        self.validate_permission(employee, "Ver_informacion")
        return self.global_transactions

    def register_global_bonus(self):
        for employee in self.employees:
            self.bonus_admin.register(employee)

    def get_total_bonus(self):
        return self.bonus_admin.get_total_bonus()

    def sort_accounts_by_number(self):
        self.accounts.sort(key=lambda account: account.account_number)

        return self.accounts

    def sort_accounts_by_balance(self):
        self.accounts.sort(key=lambda account: account.get_balance())

        return self.accounts

    def register_log(self, action: str, employee: "Empleado", status: bool, details: str):
        log = Log(employee, action, status, details)
        self.logs.append(log)
        
        return log

    def get_logs(self):
        return self.logs

    def export_accounts_json(self):
        data = []

        for account in self.accounts:
            data.append({
                "Número de cuenta": account.account_number,
                "Número de banco": account.bank_number,
                "Cliente": account.client.name,
                "Saldo": account.get_balance()
            })
        with open("accounts.json", "w") as file:
            json.dump(
                data,
                file,
                indent=4
            )
      
    def validate_transfer_limit(self, amount: float, limit: float):
        if amount <= 0:
            raise ValueError("El monto debe ser mayor a 0.")
        return amount <= limit
          
  
    def temporary_account_lock(self, account: "CuentaBancaria", minutes: int):
        if minutes <= 0:
            raise ValueError("Los minutos deben ser mayor a 0.")
        account.account_active = False
        account.locked_until = datetime.now() + timedelta(minutes=minutes)
        return account.locked_until
  

    def blacklist_client(self, employee: "Empleado", client: "Cliente", reason: str):
        self.validate_permission(employee, "Eliminar_empleado")
        if not hasattr(client, "is_blacklisted"):
            client.is_blacklisted = False
        client.is_blacklisted = True
        client.blacklist_reason = reason
        self.register_log("Cliente en lista negra", employee, True, f"Cliente {client.name} (DNI: {client.dni}) bloqueado. Motivo: {reason}")
        return True
    
    def export_data_json(self):
        data = {
            "bank_name": self.name,
            "bank_number": self.bank_number,
            "interest_rate": self.interest_rate,
            "clients": [client.to_dict() for client in self.clients],
            "employees": [employee.to_dict() for employee in self.employees],
            "accounts": [account.to_dict() for account in self.accounts],
            "transactions": [t.to_dict() for t in self.global_transactions],
            "logs": [log.to_dict() for log in self.logs]
        }

        with open(f"{self.name}_data.json", "w", encoding="utf-8") as file:
            json.dump(data, file, indent=4, ensure_ascii=False) #aquí el ensure_ascii=False hace que caracteres como ñ o los acentos se guarden, al igual que encoding="utf-8". Recuerden el próximos usos.

        return True
    
##falta import_data_json
    
