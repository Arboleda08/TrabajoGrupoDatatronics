from Servicios.Banco import Banco
from Modelos.Cuentas.CuentaBancaria import CuentaBancaria
from Modelos.Cuentas.card import Card

class ManageCards:
    def __init__(self, bank: "Banco"):
        self.bank = bank

    def create_card(self, account: CuentaBancaria, pin: str, credit: bool, debit: bool):
          card = Card(account, pin, credit, debit)
          account.cards.append(card)
          return card
  
    def block_card(self, card):
        card.is_blocked = True
  
    def unblock_card(self, card):
        card.is_blocked = False
  
    def validate_card(self, card: "Card"):
          if card.is_blocked:
              return False
          elif card.is_expired():
              return False
          else: 
              return True
          
    def change_card_pin(self, card: "Card", current_pin: str, new_pin: str):
        card.set_pin(current_pin, new_pin)
          

  